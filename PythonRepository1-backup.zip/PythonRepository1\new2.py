with open("textFile1.txt", "a", encoding="utf-8") as file:
    file.write("\nNew text here\n")