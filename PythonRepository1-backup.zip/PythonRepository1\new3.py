with open("textFile1.txt", "r", encoding="utf-8") as file:
    content = file.read()

words = content.split()

newContent = " ".join(words[0:100])

with open("textFile2.txt", "w", encoding="utf-8") as file:
    file.write(newContent)

print("success")
